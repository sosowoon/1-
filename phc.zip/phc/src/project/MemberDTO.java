package project;

public class MemberDTO {

	String id;
	String name;
	String password;
	int height;
	int age;
	int weight;
	char gender;
	int gcal;
	int gdate;
	int main;
	int lkcal;
	
	
	public int getMain() {
		return main;
	}
	public void setMain(int main) {
		this.main = main;
	}
	public int getLkcal() {
		return lkcal;
	}
	public void setLkcal(int lkcal) {
		this.lkcal = lkcal;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public int getGcal() {
		return gcal;
	}
	public void setGcal(int gcal) {
		this.gcal = gcal;
	}
	public int getGdate() {
		return gdate;
	}
	public void setGdate(int gdate) {
		this.gdate = gdate;
	}
	
}


