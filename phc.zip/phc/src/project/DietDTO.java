package project;

public class DietDTO {
	int did;
	String dname;
	int dcal;
	int carb;
	int prot;
	int fat;
	public int getDid() {
		return did;
	}
	public void setDid(int did) {
		this.did = did;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public int getDcal() {
		return dcal;
	}
	public void setDcal(int dcal) {
		this.dcal = dcal;
	}
	public int getCarb() {
		return carb;
	}
	public void setCarb(int carb) {
		this.carb = carb;
	}
	public int getProt() {
		return prot;
	}
	public void setProt(int prot) {
		this.prot = prot;
	}
	public int getFat() {
		return fat;
	}
	public void setFat(int fat) {
		this.fat = fat;
	}
	
}
